
## Canonical lock — v4
- Tag: v4-planet-intake-canonical
- URL: https://script.google.com/macros/s/AKfycbz_1EDl7P-riksySfa-TLuZAe7aTdL5k5Az1BGXS63zoGCEkW5J-eR8TpnmqGoryDo/exec
- Code.gs SHA-256: c2a3e2c67d097b6ad12a8491eba82d7c66582e44d40e8cb6646ad46d9a7ae3c9
- Locked at (UTC): 2025-09-07T21:22:00Z
