# Apps Script Code Fingerprints

These hashes are for the *repo copies* of Apps Script files at time of release.
Use them for traceability when declaring a canonical deployment.

## Code.gs

- v4 (canonical): SHA-256: c2a3e2c67d097b6ad12a8491eba82d7c66582e44d40e8cb6646ad46d9a7ae3c9
  Tag: v4-planet-intake-canonical
  Notes: First canonical lock for Planet Intake.
